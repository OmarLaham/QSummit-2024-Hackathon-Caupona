import os
import pickle

from dotenv import load_dotenv
from flask import Flask, request, jsonify
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores.azuresearch import AzureSearch
from langchain_text_splitters import CharacterTextSplitter
from langchain_community.document_loaders import MathpixPDFLoader

from student_copilot import StudentCopilot

app = Flask(__name__)
student_copilot = StudentCopilot()


### Settings ###
# Take environment variables from .env.
load_dotenv()

# OpenAI settings
openai_api_key: str = os.environ['OPENAI_API_KEY']
openai_api_version: str = '2023-05-15'
embedding_model: str = 'text-embedding-ada-002'

# Azure vector store settings
vector_store_address = os.environ['AZURE_VECTOR_STORE_ADDRESS']
vector_store_password = os.environ['AZURE_VECTOR_STORE_PASSWORD']

### Vector store ###
# OpenAIEmbeddings with OpenAI account
embeddings: OpenAIEmbeddings = OpenAIEmbeddings(
    openai_api_key = openai_api_key, 
    openai_api_version = openai_api_version, 
    model = embedding_model
)

# Create vector store
index_name: str = 'langchain-vector-demo2'
vector_store: AzureSearch = AzureSearch(
    azure_search_endpoint = vector_store_address,
    azure_search_key = vector_store_password,
    index_name = index_name,
    embedding_function = embeddings.embed_query,
)


@app.route('/')
def index():
   print('Request for index page received')
   return 'Test'


@app.route('/reset_chat_history', methods = ['GET'])
def reset_chat_history():
    # Print 
    print('Resetting chat history...')

    # Reset the chat history
    student_copilot.chat_history = []

    # Return a response (you might do more here)
    return 'Chat history reset'


@app.route('/chat', methods = ['POST'])
def chat():
    # Extracting JSON data from the request body
    data = request.get_json()
    
    # Assuming the input field is named 'input' in the JSON data
    user_input = data.get('input')

    # Do something with the user input
    print('User input:', user_input)

    # Run the student copilot
    response = student_copilot.run(user_input)

    # Return a response (you might do more here)
    return jsonify(
        {
            'output': response
        }
    )


@app.route('/get_flashcard_topics', methods = ['GET'])
def get_flashcard_topics():
    # Print
    print('Getting flashcard topics...')

    # Load the pickled flashcards file
    with open('flashcards.pkl', 'rb') as fp:
        flashcards = pickle.load(fp)

    # Return a response (you might do more here)
    return jsonify(
        {
            'topics': list(flashcards.keys())
        }
    )


@app.route('/get_flashcards_for_topic', methods = ['POST'])
def get_flashcards_for_topic():
    # Extracting JSON data from the request body
    data = request.get_json()
    
    # Assuming the topic field is named 'topic' in the JSON data
    topic = data.get('topic')

    # Load the pickled flashcards file
    with open('flashcards.pkl', 'rb') as fp:
        flashcards = pickle.load(fp)

    # Get the flashcards for the given topic
    flashcard_qa = flashcards.get(topic, [])

    # Return a response (you might do more here)
    return jsonify(
        {
            'flashcards': flashcard_qa
        }
    )


@app.route('/delete_flashcards', methods = ['GET'])
def delete_flashcards():
    # Print 
    print('Delete flash cards...')

    # Load flashcards
    with open('flashcards.pkl', 'rb') as fp:
        flashcards = pickle.load(fp)

    # Reset flashcards
    flashcards = {}
    with open('flashcards.pkl', 'wb') as fp:
        pickle.dump(flashcards, fp)

    # Return a response (you might do more here)
    return 'Flashcards deleted'


@app.route('/upload', methods = ['POST'])
def upload():
    # Check if the request contains a file
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    
    # Check if the file has a PDF extension
    if file.filename == '' or not file.filename.endswith('.pdf'):
        return jsonify({'error': 'Invalid file, please provide a PDF file'}), 400
    
    try:
        # Save the uploaded file to disk
        filename = os.path.join(os.getcwd(), file.filename)
        file.save(filename)
        
        # Load the PDF file
        loader = MathpixPDFLoader(filename)
        documents = loader.load()
        
        # Split the text and process it
        text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
        docs = text_splitter.split_documents(documents)
        
        # Add the documents to the vector store
        vector_store.add_documents(documents = docs)
        return jsonify({'message': 'PDF processing completed successfully'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500



if __name__ == '__main__':
   app.run()