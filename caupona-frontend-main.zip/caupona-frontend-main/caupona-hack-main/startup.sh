#!/bin/bash
streamlit run Upload.py --server.port $PORT
